package com.example.studentdetailapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDetailApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDetailApiApplication.class, args);
	}

}
